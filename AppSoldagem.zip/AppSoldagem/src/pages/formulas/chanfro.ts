export let chanfro = {
    espessura: 0,
    nariz: 0,
    fresta: 0,
    angulo: 0,
    acabamento: 0,
    chamfro: '',
    imagem: ''
}   