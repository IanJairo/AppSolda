export let constantes = {
    metodo: '',

}

export let valores = {
    envio: false,
    efiEquipamento: 0.9,
    valorKWh: 0.39,
    vazGas: 15,
    densidadeSol: 7860,
}

export let mm = {
    efiDeposicao: 0.9,
    cusEletrodo: 8.3,
}

export let er = {
    efiDeposicao: 0.6,
    cusEletrodo: 10.39,
    velSolda: 0.006,
}

export let at = {
    efiDeposicao: 0.85,
    cusEletrodo: 11.42,
}