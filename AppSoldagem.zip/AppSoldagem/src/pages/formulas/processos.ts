export let processos = {
    tipoOp: '',
    usarChanfro: 0,
    comCord: 0,
    corrente: 0,
    d: 0,
    mObra: 0,
    numPass: 0,
    valGas: 0,
    valInves: 0,


    //Maquina
    valResidual: 0,
    cusMedioManu: 0,
    cusDepre: 0,
    cusTotalMaquina: 0,

    //Energia
    tempoSolda: 0,
    cusTotalEnergia: 0,

    //Mão de obra
    cusTotalmObra: 0,

    //Consumíves 
    mMetalDepo: 0,
    cusMetalDepo: 0,
    cusGas: 0,
    cusTotalConsu: 0,

    //Total
    custoTotal: 0,

    
    

}