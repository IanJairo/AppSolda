import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VariaveisEntradaPage } from './variaveis-entrada';

@NgModule({
  declarations: [
    VariaveisEntradaPage,
  ],
  imports: [
    IonicPageModule.forChild(VariaveisEntradaPage),
  ],
})
export class VariaveisEntradaPageModule {}
