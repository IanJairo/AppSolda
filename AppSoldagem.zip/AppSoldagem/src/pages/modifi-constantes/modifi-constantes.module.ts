import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ModifiConstantesPage } from './modifi-constantes';

@NgModule({
  declarations: [
    ModifiConstantesPage,
  ],
  imports: [
    IonicPageModule.forChild(ModifiConstantesPage),
  ],
})
export class ModifiConstantesPageModule {}
