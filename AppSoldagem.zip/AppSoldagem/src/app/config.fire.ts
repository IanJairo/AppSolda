export const CONFIG = {
    apiKey: "AIzaSyDVig13_ZKHxPGw5lLFnez_X8JsBCQ9LUM",
    authDomain: "soldagem-b8812.firebaseapp.com",
    databaseURL: "https://soldagem-b8812.firebaseio.com",
    projectId: "soldagem-b8812",
    storageBucket: "soldagem-b8812.appspot.com",
    messagingSenderId: "54724802815",
    appId: "1:54724802815:web:5fdc98b7030c608bf9b4ca"

}